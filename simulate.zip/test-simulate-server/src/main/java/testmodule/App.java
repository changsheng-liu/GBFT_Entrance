package testmodule;

import java.io.IOException;


public class App {
    public static void main(String[] args) throws IOException, InterruptedException {
        GBFTListenerModule server = new GBFTListenerModule();
        server.start();
        server.blockUntilShutdown();
    }
}