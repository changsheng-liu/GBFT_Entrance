package testmodule;

import java.io.IOException;

import ucsc.gbft.comm.ConfirmReply;
import ucsc.gbft.comm.ConsensusGrpc;
import ucsc.gbft.comm.ConsensusRequest;
import ucsc.gbft.comm.EndRequest;
import ucsc.gbft.comm.StartRequest;
import ucsc.gbft.comm.ViewChangeRequest;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class GBFTListenerModule {
    private Server server;

    
    public void start() throws IOException {
        server = ServerBuilder.forPort(20000)
                .addService(new GBFTServerImpl())
                .build()
                .start();
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                stopServer();
            }
        });
    }
        
    public void stopServer() {
        if (server != null) {
            server.shutdown();
        }
    }
        
    public void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }
}

final class GBFTServerImpl extends ConsensusGrpc.ConsensusImplBase {
    
    private GBFTSendingModule sender;

    @Override
    public void startMessage(StartRequest req,  StreamObserver<ConfirmReply> responseObserver) {
        if(sender == null) {
            sender = new GBFTSendingModule();
        }
        sender.sendingEndMessage(req);
        System.out.println(req.getRandomId());
        ConfirmReply reply = ConfirmReply.newBuilder().setConfirm(1).build();
        responseObserver.onNext(reply);
        responseObserver.onCompleted();
    }

}