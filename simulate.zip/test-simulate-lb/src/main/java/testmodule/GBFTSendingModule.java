package testmodule;

import java.util.concurrent.TimeUnit;

import ucsc.gbft.comm.ConsensusGrpc;
import ucsc.gbft.comm.EndRequest;
import ucsc.gbft.comm.StartRequest;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

public class GBFTSendingModule {

    private ManagedChannel channel;
    public ConsensusGrpc.ConsensusBlockingStub blockingStub;
  
    public GBFTSendingModule(){
        channel =  ManagedChannelBuilder.forAddress("127.0.0.1", 20000).usePlaintext().build();
        blockingStub = ConsensusGrpc.newBlockingStub(channel);
    }

    public void shutdown(int k) throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }

}