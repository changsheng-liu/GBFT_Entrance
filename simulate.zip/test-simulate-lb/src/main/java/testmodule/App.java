package testmodule;

import io.grpc.StatusRuntimeException;

import java.io.IOException;


public class App {
    private GBFTSendingModule sender;

    public static void main(String[] args) throws IOException, InterruptedException {
        GBFTSendingModule sender = new GBFTSendingModule();
        ucsc.gbft.comm.StartRequest.Builder b = ucsc.gbft.comm.StartRequest.newBuilder();
        b.setRandomId(453943.3434);
        b.setKey("hello");
        b.setValue("world");
        ucsc.gbft.comm.StartRequest r = b.build();
        try {
            sender.blockingStub.startMessage(r);
        } catch (StatusRuntimeException e) {
            System.out.println("fail to response");
        }

    }
}